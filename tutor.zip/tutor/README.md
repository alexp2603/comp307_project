#comp307_project
Alexandre Perron
Adam Li
Deklan Chung


Technologies used:
  1. HTML, CSS, JS
  2. XAMPP Stack (5.6.1)

SERVER INFORMATION:
	Use Localhost/comp307_project to access
	Database name -> tutor
