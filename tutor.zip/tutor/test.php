<?php

	$options.='<option>'.$row['COURSE_ID'].'</option>';
?>