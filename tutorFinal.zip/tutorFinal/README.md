#comp307_project
Alexandre Perron
Adam Li
Deklan Chung

Project Info:

'TUTOR' is a platform for students to offer and sign-up for tutoring services offered by other students. Users can

-Create their own accounts with their own personal information
-Select what courses they can tutor
-Reach out to other students for tutoring engagement
-Accept/Decline tutoring engagements 
-Manage their current engagements

Technologies used:
  1. HTML5, CSS, JS
  	a. Bootstrap framework
  	b. AJAX+JQuery for interactive search bar in "find available tutors page"
  	c. JS Function to validate sign-ups
  	d. A lot of custom CSS Files
  2. XAMPP Stack (5.6.1)
  		PHP to interface and generate webpages
  			Slim to pass some requests
  		SQL Database
  			MySQLi to interface
  3. Google Maps
  4. Security through Caesar encryption


SETUP INFORMATION
	Run on your localhost in htdocs
	Import SQL database by copy/pasting as a qeury the SQL file found in the 'SQL' folder as tutor.sql 