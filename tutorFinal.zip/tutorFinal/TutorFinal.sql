-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2017 at 07:55 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutor`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `COURSE_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`COURSE_ID`) VALUES
('BUSA 150'),
('BUSA 307'),
('BUSA 499'),
('COMP 202'),
('COMP 303'),
('FINE 151');

-- --------------------------------------------------------

--
-- Table structure for table `engagements`
--

CREATE TABLE `engagements` (
  `ENGAGEMENT_ID` int(11) NOT NULL,
  `ENGAGEMENT_STUDENT` int(11) DEFAULT NULL,
  `ENGAGEMENT_TUTOR` int(11) DEFAULT NULL,
  `ENGAGEMENT_DATETIME` datetime DEFAULT NULL,
  `ENGAGEMENT_DURATION` int(11) DEFAULT NULL,
  `ENGAGEMENT_LOCATION` varchar(255) DEFAULT NULL,
  `ENGAGEMENT_FEE` int(11) DEFAULT NULL,
  `ENGAGEMENT_COURSEID` varchar(255) DEFAULT NULL,
  `ENGAGEMENT_TUTORNAME` varchar(255) DEFAULT NULL,
  `ENGAGEMENT_ACCEPTED` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `engagements`
--

INSERT INTO `engagements` (`ENGAGEMENT_ID`, `ENGAGEMENT_STUDENT`, `ENGAGEMENT_TUTOR`, `ENGAGEMENT_DATETIME`, `ENGAGEMENT_DURATION`, `ENGAGEMENT_LOCATION`, `ENGAGEMENT_FEE`, `ENGAGEMENT_COURSEID`, `ENGAGEMENT_TUTORNAME`, `ENGAGEMENT_ACCEPTED`) VALUES
(12, 260634018, 260634017, '2017-12-11 21:00:00', 25, 'Bronfman Building', 25, 'COMP 202', 'Alex', b'1'),
(13, 260634018, 260634017, '2017-12-12 18:00:00', 25, 'Trottier Building', 25, 'COMP 303', 'Alex', b'1'),
(15, 260634017, 260634018, '2017-12-14 15:00:00', 25, 'Redpath Library', 125, 'BUSA 499', 'Jack', b'1'),
(16, 260634017, 260634018, '2020-02-22 13:00:00', 25, 'Redpath Library', 25, 'BUSA 499', 'Jack', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `STUDENT_ID` int(11) NOT NULL,
  `STUDENT_NAME` varchar(255) DEFAULT NULL,
  `STUDENT_PASSWORD` varchar(255) DEFAULT NULL,
  `STUDENT_EMAIL` varchar(255) DEFAULT NULL,
  `STUDENT_YEAROFSTUDY` enum('U0','U1','U2','U3','U3+') DEFAULT NULL,
  `STUDENT_PHONE` varchar(255) DEFAULT NULL,
  `STUDENT_COURSE1` varchar(255) DEFAULT NULL,
  `STUDENT_COURSE2` varchar(255) DEFAULT NULL,
  `STUDENT_COURSE3` varchar(255) DEFAULT NULL,
  `STUDENT_COURSE4` varchar(255) DEFAULT NULL,
  `STUDENT_COURSE5` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`STUDENT_ID`, `STUDENT_NAME`, `STUDENT_PASSWORD`, `STUDENT_EMAIL`, `STUDENT_YEAROFSTUDY`, `STUDENT_PHONE`, `STUDENT_COURSE1`, `STUDENT_COURSE2`, `STUDENT_COURSE3`, `STUDENT_COURSE4`, `STUDENT_COURSE5`) VALUES
(260634010, 'Alex', 'wC+419GPz9MNT2eJnNwIcw==', 'alexandre.perron@mail.mcgill.ca', 'U0', '(454)454-4444', NULL, NULL, NULL, NULL, NULL),
(260634011, 'Hubert', 'wC+419GPz9MNT2eJnNwIcw==', 'hubert@mail.mcgill.ca', 'U0', '(545)344-4444', NULL, NULL, NULL, NULL, NULL),
(260634016, 'SomeDude', 'wC+419GPz9MNT2eJnNwIcw==', 'hello@mail.mcgill.ca', 'U3', '(454)454-4545', NULL, NULL, NULL, NULL, NULL),
(260634017, 'Alex', 'wC+419GPz9MNT2eJnNwIcw==', 'alexandre.perron@mail.mcgill.ca', 'U2', '(514)625-0454', 'BUSA 150', 'BUSA 307', 'BUSA 499', 'COMP 202', 'COMP 303'),
(260634018, 'Jack', 'wC+419GPz9MNT2eJnNwIcw==', 'jack@mail.mcgill.ca', 'U3', '(514)435-0454', 'BUSA 150', 'BUSA 307', 'BUSA 499', 'COMP 202', 'COMP 303'),
(260634019, 'Oliver', 'wC+419GPz9MNT2eJnNwIcw==', 'oliver@mail.mcgill.ca', 'U0', '(514)254-0342', NULL, NULL, NULL, NULL, NULL),
(260634020, 'Daniel', 'wC+419GPz9MNT2eJnNwIcw==', 'daniel@mail.mcgill.ca', 'U0', '(514)565-4544', NULL, NULL, NULL, NULL, NULL),
(260634021, 'Sam', 'wC+419GPz9MNT2eJnNwIcw==', 'sam@mail.mcgill.ca', 'U0', '(545)445-2342', NULL, NULL, NULL, NULL, NULL),
(260634022, 'Phil', 'wC+419GPz9MNT2eJnNwIcw==', 'phil@mail.mcgill.ca', 'U0', '(454)345-3242', NULL, NULL, NULL, NULL, NULL),
(260634023, 'sammy', 'wC+419GPz9MNT2eJnNwIcw==', 'sammy@mail.mcgill.ca', 'U0', '(454)567-8666', NULL, NULL, NULL, NULL, NULL),
(260635015, 'Annie', 'wC+419GPz9MNT2eJnNwIcw==', 'annie@mail.mcgill.ca', 'U0', '(545)454-4444', NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`COURSE_ID`);

--
-- Indexes for table `engagements`
--
ALTER TABLE `engagements`
  ADD PRIMARY KEY (`ENGAGEMENT_ID`),
  ADD KEY `ENGAGEMENT_STUDENT` (`ENGAGEMENT_STUDENT`),
  ADD KEY `ENGAGEMENT_TUTOR` (`ENGAGEMENT_TUTOR`),
  ADD KEY `ENGAGEMENT_COURSEID` (`ENGAGEMENT_COURSEID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`STUDENT_ID`),
  ADD KEY `STUDENT_COURSE1` (`STUDENT_COURSE1`),
  ADD KEY `STUDENT_COURSE2` (`STUDENT_COURSE2`),
  ADD KEY `STUDENT_COURSE3` (`STUDENT_COURSE3`),
  ADD KEY `STUDENT_COURSE4` (`STUDENT_COURSE4`),
  ADD KEY `STUDENT_COURSE5` (`STUDENT_COURSE5`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `engagements`
--
ALTER TABLE `engagements`
  MODIFY `ENGAGEMENT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `engagements`
--
ALTER TABLE `engagements`
  ADD CONSTRAINT `engagements_ibfk_1` FOREIGN KEY (`ENGAGEMENT_STUDENT`) REFERENCES `students` (`STUDENT_ID`),
  ADD CONSTRAINT `engagements_ibfk_2` FOREIGN KEY (`ENGAGEMENT_TUTOR`) REFERENCES `students` (`STUDENT_ID`),
  ADD CONSTRAINT `engagements_ibfk_3` FOREIGN KEY (`ENGAGEMENT_COURSEID`) REFERENCES `courses` (`COURSE_ID`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`STUDENT_COURSE1`) REFERENCES `courses` (`COURSE_ID`),
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`STUDENT_COURSE2`) REFERENCES `courses` (`COURSE_ID`),
  ADD CONSTRAINT `students_ibfk_3` FOREIGN KEY (`STUDENT_COURSE3`) REFERENCES `courses` (`COURSE_ID`),
  ADD CONSTRAINT `students_ibfk_4` FOREIGN KEY (`STUDENT_COURSE4`) REFERENCES `courses` (`COURSE_ID`),
  ADD CONSTRAINT `students_ibfk_5` FOREIGN KEY (`STUDENT_COURSE5`) REFERENCES `courses` (`COURSE_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
