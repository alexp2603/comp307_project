<?php
//Connects to "Store" database
$host = "localhost";
$user = "root";
$pass = "";
$db_name = "tutor";
$mysqli = new mysqli($host, $user, $pass, $db_name);